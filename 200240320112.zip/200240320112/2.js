function login() {
    let input1 = document.getElementById("inputId1").Value;

    let input2 = document.getElementById("inputId2").Value;

    let commentBox = document.getElementById("comment-box");

    let name = commentbox.children[0].children[0];
    name.innerHTML = input1;

    let password = commentbox.children[0].children[1];
    namepassword.innerHTML = input2;

    let newcopy = name.parentElement.children[0].cloneNode(true);

    commentBox.insertBefore(newcopy, commentBox.firstChild);

}